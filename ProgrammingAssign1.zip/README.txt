Personnel information:
	written by Bill Molchan
File list
	storage_mgr.h
	storage_mgr.c
	test_helper.h
	dberror.h
	dberror.c
	test_assign1_1.c
	test_assign1_2.c
	makefile
Milestone
	passed all test-cases

Installation instructions
	Use the  makefile with gcc to compile the tests
	Run testOne and testTwo to validate program functionality

Function Descriptions:
	No additional functions
	Original functions can be found at:
		cs.iit.edu/~cs525/assign1.html
Error Codes:
	None additional
Data Structure:
	None additional
Additional Files:
	None

r
u
		cs.iit.edu/~cs
r
u
	cs.iit.edu/~cs 
